
import './globals.css';

export const metadata = {
  title: 'Verses for Shibbuu',
  description: 'A poetic journey for a best friend',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
