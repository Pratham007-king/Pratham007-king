"use client";

import { useState } from 'react';
import { motion } from 'framer-motion';

const poems = [
  {
    title: "Where Light Begins",
    puzzle: "Unscramble this: 'higlt'",
    answer: "light",
    poem: `In the hush before morning, I whispered your name,
And the stars tucked in tighter, glowing with flame.
You are the dawn in a world made of dusk,
Turning quiet to color, and silver to trust.`
  },
  {
    title: "The Garden of Words",
    puzzle: "Fill in the blank: 'A _____ bloomed there after just a short while.'",
    answer: "tulip",
    poem: `I planted a wish in the soil of your smile,
A tulip bloomed there after just a short while.
It swayed with your laughter, it blushed with your care,
A petal-soft miracle, floating midair.`
  },
  {
    title: "Mirror of the Moon",
    puzzle: "Match this couplet: 'If ever the moon forgets to glow, ___'",
    answer: "I’ll hang you the stars, row after row",
    poem: `If ever the moon forgets to glow,
I’ll hang you the stars, row after row.
For in your eyes is a sky so wide,
The constellations drift and hide.`
  },
  {
    title: "Your Name in the Wind",
    puzzle: "Haiku: Rearrange — 'Tulips bow / Shibbuu walks through spring / Winds hush low'",
    answer: "Shibbuu walks through spring, Tulips bow along her path, Even winds hush low",
    poem: `Shibbuu walks through spring,
Tulips bow along her path—
Even winds hush low.`
  },
  {
    title: "Verses for You",
    puzzle: "Final unlock - just click to reveal",
    answer: "click",
    poem: `Here’s to the moments I don’t say enough:
Your light is tender, and your love is tough.
You paint the world with a violet hue,
And every soft verse is written for you.`
  }
];

export default function Home() {
  const [level, setLevel] = useState(0);
  const [input, setInput] = useState("");
  const [solved, setSolved] = useState(false);

  const current = poems[level];

  function checkAnswer() {
    if (input.trim().toLowerCase() === current.answer.toLowerCase()) {
      setSolved(true);
    }
  }

  function nextLevel() {
    setInput("");
    setSolved(false);
    setLevel(level + 1);
  }

  return (
    <div className="min-h-screen bg-purple-100 flex flex-col items-center justify-center p-6 text-center text-purple-900">
      <motion.h1 className="text-4xl font-bold mb-4" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        {current.title}
      </motion.h1>
      <motion.p className="text-lg mb-6" initial={{ y: -10, opacity: 0 }} animate={{ y: 0, opacity: 1 }}>
        {current.puzzle}
      </motion.p>

      {!solved ? (
        <div className="space-y-4">
          <input
            className="px-4 py-2 rounded border border-purple-400"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type your answer here"
          />
          <button className="bg-purple-500 text-white px-4 py-2 rounded" onClick={checkAnswer}>Submit</button>
        </div>
      ) : (
        <motion.div className="mt-6 max-w-xl text-lg bg-white p-4 rounded-xl shadow" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
          <pre className="whitespace-pre-wrap font-serif">{current.poem}</pre>
          {level < poems.length - 1 && (
            <button className="mt-4 bg-purple-600 text-white px-4 py-2 rounded" onClick={nextLevel}>Next Poem</button>
          )}
          {level === poems.length - 1 && <p className="mt-4 font-semibold">The journey ends, but the verses live on.</p>}
        </motion.div>
      )}
    </div>
  );
}
